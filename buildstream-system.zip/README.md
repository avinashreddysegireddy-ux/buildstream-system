# BuildStream System

A simple base template for a CI/CD-style pipeline dashboard. Builds move
through stages (Fetch → Install → Build → Test → Package → Deploy) while
logs stream live into an on-screen console, with a history panel tracking
recent runs.

## Files

- `index.html` — page structure/markup
- `style.css` — all styling (dark, pipeline/blueprint themed UI)
- `script.js` — pipeline logic, log streaming simulation, build history

## Running it

No build step or dependencies required. Just open `index.html` directly
in a browser, or serve the folder with any static server, e.g.:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## How it works

- Click **Run build** to kick off a simulated pipeline run.
- Each stage lights up amber while "running", turns green when done.
- Log lines stream into the console panel in real time (simulated with
  timed delays in `script.js`).
- There's a small random chance (~12%) a stage fails, to demonstrate the
  failure state (red stage, red badge).
- Finished builds are added to the "Recent builds" list with their status
  and duration.

## Extending this base

This is a front-end-only simulation — the "streaming" is just timed
JavaScript, not a real build backend. To turn it into something real:

- Replace `startBuild()` in `script.js` with a call to your actual CI
  system (GitHub Actions, GitLab CI, Jenkins, a custom Node/Docker
  runner, etc.).
- Stream real log output using WebSockets or Server-Sent Events (SSE)
  instead of the `setTimeout`-based simulation.
- Persist build history in a database instead of the in-memory `history`
  array.
- Add authentication if this will be exposed beyond local/internal use.
